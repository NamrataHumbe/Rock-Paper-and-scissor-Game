# rock, paper and scissor:
import random
def rps(boat,player):
    
    # if two values are equal declare tie
    if (boat == player):
        return None

    # check for all possiblity when coputer chose rock(r)
    elif(boat == 'r'):
        if(player == 'p'):
            return True
        else:
            return False

    # check for all possiblity when coputer chose paper(p)
    elif(boat == 'p'):
        if(player == 'r'):
            return False
        else:
            return True
        
    # check for all possiblity when coputer chose scissor(s)
    elif(boat == 's'):
        if(player == 'r'):
            return True
        else:
            return False

m = 1
while(m>0):
    b = random.randint(1,3)
    if(b == 1):
        boat = 'r'
    elif(b == 2):
        boat = 'p'
    else:
        boat = 's'

    print("You want to play game(Y/N)")
    play_again=input("Enter your choice:")
    if(play_again=='Y' or play_again=='y'):
        player = input("Enter your choice rock(r), paper(p) and scissor(s)? : ")
        print("Boat choice rock(r), paper(p) and scissor(s)? : ",boat)  
        a = rps(boat,player)
        if(a == None):
            print("Game is tie...")
        elif(a):
            print("You win...!")
        else:
            print("You lose...!")

    if(play_again=='N' or play_again=='n'):
        m = 0   
        print("Thank you to play game...")